<?php
$sql = "select * from usercourse where username = '" . $_SESSION['userid'] . "'";