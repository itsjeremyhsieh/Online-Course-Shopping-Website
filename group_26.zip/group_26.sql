-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 05, 2022 at 09:03 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group_26`
--
CREATE DATABASE IF NOT EXISTS `group_26` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `group_26`;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `userid` varchar(30) NOT NULL,
  `courseid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `coupon`
--

CREATE TABLE `coupon` (
  `userid` varchar(30) NOT NULL,
  `couponid` varchar(30) NOT NULL,
  `couponname` varchar(30) NOT NULL,
  `prize` int(11) NOT NULL,
  `validdate` date NOT NULL,
  `used` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coupon`
--

INSERT INTO `coupon` (`userid`, `couponid`, `couponname`, `prize`, `validdate`, `used`) VALUES
('member', '#bday123', '生日禮券', 2000, '2022-12-31', 0),
('member', '#hellogift', '新用戶禮券', 300, '2022-08-31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `smt` varchar(5) NOT NULL,
  `teacher` varchar(10) NOT NULL,
  `length` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `sold` int(11) NOT NULL DEFAULT 0,
  `valid` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `download` text NOT NULL DEFAULT 'sample1.pdf'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `name`, `subject`, `grade`, `smt`, `teacher`, `length`, `total`, `price`, `sold`, `valid`, `description`, `download`) VALUES
(28, '傑瑞自然-學測總複習', '自然', '高中通用', '通用', '傑瑞老師', 60, 21, 8600, 54, 3, '本課程為高中自然科學學測範圍之複習課程。課程分為化學、物理、生物與地球科學四個部分。', 'sample1.pdf'),
(27, '傑瑞自然-選修自然', '自然', '高中三年級', '下學期', '傑瑞老師', 80, 26, 5200, 54, 1, '本課程旨在為準備分科測驗之學生提供快速且容易理解的自然科學重點觀念課程。', 'sample1.pdf'),
(22, '傑瑞自然-高中一年級(上學期)', '自然', '高中一年級', '上學期', '傑瑞老師', 80, 26, 5200, 54, 1, '本課程為高一上學期之自然科學課程。課程前期將複習國中自然觀念，後將基於國中觀念向上延伸，確保學生有能力克服國高中階段的落差。', 'sample1.pdf'),
(23, '傑瑞自然-高中一年級(下學期)', '自然', '高中一年級', '下學期', '傑瑞老師', 80, 26, 5200, 54, 1, '本課程為高一下學期課內英文課程，由傑瑞老師自編跨版本教材，搭配新課綱素養題型，幫助學生百戰百勝。', 'sample1.pdf'),
(26, '傑瑞自然-高中三年級(上學期)', '自然', '高中二年級', '上學期', '傑瑞老師', 80, 26, 5200, 54, 1, '本課程除教授高三上學期之自然科學觀念，亦會複習高一、高二之重點觀念，為學測作準備。', 'sample1.pdf'),
(24, '傑瑞自然-高中二年級(上學期)', '自然', '高中二年級', '上學期', '傑瑞老師', 80, 26, 5200, 54, 1, '本課程涵蓋範圍為高二上學期之課綱內容。教學風格採用先理解後練習技藝之方式，使學生能在輕鬆的環境下學習成長。', 'sample1.pdf'),
(25, '傑瑞自然-高中二年級(下學期)', '自然', '高中二年級', '下學期', '傑瑞老師', 80, 26, 5200, 54, 1, '本課程為高二下學期自然科學課程。', 'sample1.pdf'),
(18, '戴育數學-高中一年級(上學期)', '數學', '高中一年級', '上學期', '戴育老師', 60, 18, 4100, 55, 1, '本課程為高一上學期之數學課程。數學的學習著重於思考與推理，這方面源於不斷的練習，為使學生有充分的練習機會，本課程將依題目的深淺分為三類:基本、進階與挑戰，使學生不斷深入、理解。', 'sample1.pdf'),
(19, '戴育數學-高中一年級(下學期)', '數學', '高中一年級', '下學期', '戴育老師', 60, 19, 4100, 63, 1, '本課程為高一下學期之數學課程，本課程教師自選許多經典例題，幫助學生延伸觀念。', 'sample1.pdf'),
(20, '戴育數學-高中二年級(上學期)', '數學', '高中二年級', '上學期', '戴育老師', 60, 20, 4100, 71, 1, '本課程為高二上學期之數學課程，本課程注重提升定理的應用及整理概念，診斷學習效果。', 'sample1.pdf'),
(21, '戴育數學-高中二年級(下學期)', '數學', '高中二年級', '下學期', '戴育老師', 60, 20, 4100, 68, 1, '本課程為高二下學期之數學課程，培養學生熟悉課程內容，了解定理的由來、應用。', 'sample1.pdf'),
(16, '戴育高中選修數學甲(上)', '數學', '高中三年級', '上學期', '戴育老師', 70, 25, 4200, 116, 3, '本課程配合課本且題目的選取皆由基礎觀念著手，再慢慢引導學生融會貫通', 'sample1.pdf'),
(17, '戴育高中選修數學甲(下)', '數學', '高中三年級', '下學期', '戴育老師', 70, 24, 4200, 120, 1, '掌握主題，培養學生熟悉高中選修數學甲的課程內容，了解定理的由來、應用及整理概念，診斷學習效果', 'sample1.pdf'),
(51, '月月社會-學測總複習', '社會', '高中通用', '通用', '月月老師', 60, 24, 4200, 72, 1, '掌握主題，培養學生熟悉高中社會科的課程內容，課程分為公民、地理、歷史三個部分，本課程內附有教師自出觀念題，協助學生診斷自我學習成果。', 'sample1.pdf'),
(50, '月月社會-社會科精選歷屆考古講解', '社會', '高中通用', '通用', '月月老師', 60, 20, 4200, 67, 1, '本課程配合課本且題目的選取皆由易錯觀念著手，引導學生重新複習高一、高二之社會科觀念。', 'sample1.pdf'),
(44, '月月社會-高中一年級(上學期)', '社會', '高中一年級', '上學期', '月月老師', 50, 19, 3800, 31, 1, '本課程為高一上學期之社會課程。課程前期將複習國中社會觀念，後將基於國中觀念向上延伸，幫助學生銜接高中社會科。', 'sample1.pdf'),
(45, '月月社會-高中一年級(下學期)', '社會', '高中一年級', '下學期', '月月老師', 50, 19, 3800, 22, 1, '本課程為高一下學期之社會課程，本課程根據課程綱要編排，附有各種圖表、照片，以幫助學生了解內容，提高學習興趣。', 'sample1.pdf'),
(48, '月月社會-高中三年級(上學期)', '社會', '高中二年級', '上學期', '月月老師', 50, 18, 3800, 51, 1, '本課程為高三上學期之社會課程，扣連各區域與台灣關係的實際個案，藉此拉近學習的距離及提高學習興趣。', 'sample1.pdf'),
(49, '月月社會-高中三年級(下學期)', '社會', '高中三年級', '下學期', '月月老師', 50, 20, 3800, 53, 1, '本課程為高三下學期之社會課程，本課程除高三社會外，亦會複習高一、高二之觀念，協助學生應對學測。', 'sample1.pdf'),
(46, '月月社會-高中二年級(上學期)', '社會', '高中二年級', '上學期', '月月老師', 50, 18, 3800, 45, 1, '本課程為高二上學期之社會課程，本課程精選操作型題目題供學生對於相關題目的實際演練，進而思考並討論。', 'sample1.pdf'),
(47, '月月社會-高中二年級(下學期)', '社會', '高中二年級', '下學期', '月月老師', 50, 18, 3800, 47, 1, '本課程為高二下學期之社會課程，本課程精選開放型題目題，嘗試引導學生注意與生活應用，進而思考並討論。', 'sample1.pdf'),
(36, '玉育自然-國中一年級(上學期)', '自然', '國中一年級', '上學期', '玉育老師', 50, 26, 3500, 54, 1, '本課程為國中之自然科學國一課程。課程前期將簡單介紹國中自然觀念，後將基於觀念向上延伸，確保學生有充分理解自然科學之概念。', 'sample1.pdf'),
(37, '玉育自然-國中一年級(下學期)', '自然', '國中一年級', '下學期', '玉育老師', 50, 21, 3500, 24, 1, '本課程為國中之自然科學國一課程。依照課程綱要的範圍，協助學生深入理解國中自然。', 'sample1.pdf'),
(40, '玉育自然-國中三年級(上學期)', '自然', '國中三年級', '上學期', '玉育老師', 50, 18, 3500, 65, 1, '本課程除教授國三之自然科學觀念，亦會複習國一、國二之重點觀念，為會考作準備。', 'sample1.pdf'),
(41, '玉育自然-國中三年級(下學期)', '自然', '國中三年級', '下學期', '玉育老師', 50, 26, 3500, 52, 1, '本課程除教授國三之自然科學觀念，亦會為學生提供自然科學重點觀念課程及歷屆精選考古題講解。', 'sample1.pdf'),
(38, '玉育自然-國中二年級(上學期)', '自然', '國中二年級', '上學期', '玉育老師', 50, 18, 3500, 68, 1, '本課程為國中之自然科學國二課程。教學風格採用先理解後練習之方式，使學生能自我診斷學習成長。', 'sample1.pdf'),
(39, '玉育自然-國中二年級(下學期)', '自然', '國中二年級', '下學期', '玉育老師', 50, 18, 3500, 15, 1, '本課程為國中之自然科學國二課程。本課程教師將會實作實驗，除可適度配合內容以幫助學生學習重要的相關知識，亦可加深學生印象，提高學習興趣。', 'sample1.pdf'),
(43, '玉育自然-會考總複習', '自然', '國中通用', '通用', '玉育老師', 70, 26, 4300, 71, 1, '掌握主題，培養學生熟悉國中自然科學的課程內容，加深概念整理，診斷學習效果。', 'sample1.pdf'),
(42, '玉育自然-自然科精選歷屆考古講解', '自然', '國中三年級', '通用', '玉育老師', 70, 26, 4300, 63, 1, '本課程為高中自然科學會考範圍之複習課程。課程分為化學、物理、生物與地球科學四個部分。', 'sample1.pdf'),
(29, '瑞米社會-國中一年級(上學期)', '社會', '國中一年級', '上學期', '瑞米老師', 50, 18, 3600, 24, 1, '本課程為國一上學期之社會課程。課程前期將學習國中社會觀念，基於觀念向上延伸。', 'sample1.pdf'),
(30, '瑞米社會-國中一年級(下學期)', '社會', '國中一年級', '下學期', '瑞米老師', 50, 18, 3600, 68, 1, '本課程為國一下學期之社會課程，本課程根據課程綱要編排，附有各種圖表、照片，以幫助學生了解內容，提高學習興趣。', 'sample1.pdf'),
(33, '瑞米社會-國中三年級(上學期)', '社會', '國中三年級', '上學期', '瑞米老師', 50, 18, 3600, 52, 1, '本課程為國三上學期之社會課程，扣連實際個案，藉此拉近學習的距離及提高學習興趣。', 'sample1.pdf'),
(34, '瑞米社會-國中三年級(下學期)', '社會', '國中三年級', '下學期', '瑞米老師', 50, 18, 3600, 40, 1, '本課程為國三下學期之社會課程，本課程除國三社會外，亦會複習國一、國二之觀念，協助學生應對會考。', 'sample1.pdf'),
(31, '瑞米社會-國中二年級(上學期)', '社會', '國中二年級', '上學期', '瑞米老師', 50, 18, 3600, 15, 1, '本課程為國二上學期之社會課程，本課程精選題目題供學生對於相關題目的實際演練，進而思考並討論。', 'sample1.pdf'),
(32, '瑞米社會-國中二年級(下學期)', '社會', '國中二年級', '下學期', '瑞米老師', 50, 18, 3600, 65, 1, '本課程為國二下學期之社會課程，本課程引導學生注意與生活應用，進而思考並討論。', 'sample1.pdf'),
(35, '瑞米社會-會考總複習', '社會', '國中通用', '通用', '瑞米老師', 50, 32, 6800, 197, 3, '本課程配合課本且題目的選取皆由易錯觀念著手，引導學生重新複習國一、國二之社會科觀念。', 'sample1.pdf'),
(15, '維琪國文-學測歷屆試題(講解精選考題)', '國文', '高中三年級', '通用', '維琪老師', 50, 22, 4300, 73, 3, '國學的基本知識部分著重在傳統的經、史、子、集等重要學術思想內涵與特質。注重課本內容與歷屆考題的的結合，提供考生整合與活用課內所學的知識與能力', 'sample1.pdf'),
(14, '維琪國文-觀念總複習', '國文', '高中通用', '通用', '維琪老師', 50, 30, 4200, 67, 3, '選材依大考常考類型，歸納、分類為十大主題，藉由文章分析、易混淆觀念的統整，拓展閱讀廣度、加強讀解能力，期能使「閱讀」成為充滿興趣的「悅讀」。', 'sample1.pdf'),
(8, '維琪國文-高中一年級(上學期)', '國文', '高中一年級', '上學期', '維琪老師', 45, 12, 2900, 31, 1, '本課程為高一上學期之國文課程。課程前期將複習國中國文觀念，後將基於國中觀念向上延伸，幫助學生銜接高中國文。', 'sample1.pdf'),
(9, '維琪國文-高中一年級(下學期)', '國文', '高中一年級', '下學期', '維琪老師', 45, 13, 2900, 22, 1, '本課程為高一下學期之國文課程，本課程根據課程綱要，每課選入一至二課古典詩詞教材，廷升學生閱讀與欣賞能力。', 'sample1.pdf'),
(12, '維琪國文-高中三年級(上學期)', '國文', '高中三年級', '上學期', '維琪老師', 45, 16, 2900, 51, 1, '本課程為高三上學期之國文課程，銜接高二課程，採用分類方式講解，可使學生於學習之後得到較有系統的認識。', 'sample1.pdf'),
(13, '維琪國文-高中三年級(下學期)', '國文', '高中三年級', '下學期', '維琪老師', 45, 16, 2900, 53, 1, '本課程為高三下學期之國文課程，深入探討中華文化之精隨，切合學測範圍，增加學生研讀之深度。', 'sample1.pdf'),
(10, '維琪國文-高中二年級(上學期)', '國文', '高中二年級', '上學期', '維琪老師', 45, 15, 2900, 45, 1, '本課程為高二上學期之國文課程，本課程注重提升學生寫作能力，增進文學作品的欣賞程度。', 'sample1.pdf'),
(11, '維琪國文-高中二年級(下學期)', '國文', '高中二年級', '下學期', '維琪老師', 45, 14, 2900, 47, 1, '本課程為高二下學期之國文課程，本課程著重探討論語、孟子、學庸。', 'sample1.pdf'),
(1, '謝宥英文-國中一年級(上學期)', '英文', '國中一年級', '上學期', '謝宥老師', 50, 18, 3800, 68, 1, '本課程為銜接國小與國中英文之英文課程。從最基礎的英文字母開始，一步步引導學生，使學生不再為外國語言，並習得第二語言的專長。\r\n', 'sample1.pdf'),
(2, '謝宥英文-國中一年級(下學期)', '英文', '國中一年級', '下學期', '謝宥老師', 50, 24, 3800, 68, 1, '本課程特別著重在口語練習與聽力訓練，特別聘請英語母語者錄製音檔，期盼藉由多聽、多說以提升學童的英文語感。', '2.pdf'),
(5, '謝宥英文-國中三年級(上學期)', '英文', '國中三年級', '上學期', '謝宥老師', 50, 20, 3800, 85, 1, '本課程旨在提昇學生的課內英文聽說讀寫能力；教學內容橫跨各版本，涵蓋各方面全方位能力訓練，除高三課程外，亦會複習國一、國二英文內容，為即將到來的會考提前複習。', 'sample1.pdf'),
(6, '謝宥英文-國中三年級(下學期)', '英文', '國中三年級', '下學期', '謝宥老師', 50, 16, 3800, 128, 1, '本課程為國三下學期英文課程。國三課程編排主要著重在複習已知文法句型觀念與補充考試常見字彙。', 'sample1.pdf'),
(3, '謝宥英文-國中二年級(上學期)', '英文', '國中二年級', '上學期', '謝宥老師', 50, 20, 3800, 124, 1, '邁入國中第二階段，學生應開始具備將想法以英文表達之基本能力，本教材除單字累積外，著重訓練造完整句子的能力。教材最後搭配測驗題目，幫助檢視學生的學習成效。', 'sample1.pdf'),
(4, '謝宥英文-國中二年級(下學期)', '英文', '國中二年級', '下學期', '謝宥老師', 50, 12, 3800, 128, 1, '本課程涵蓋國二下學期的英文課程，並將先修部分國三上學期之英文文法觀念，提前為國中教育會考準備。', 'sample1.pdf'),
(7, '謝宥英文-國中會考總複習', '英文', '國中通用', '通用', '謝宥老師', 50, 40, 6800, 623, 3, '本課程為國中教育會考複習課程；完整歸納國中3年新綱課程單字與文法，完整掌握應考重點！收錄長篇閱讀、圖表題、素養題，精確備足會考應試實力。課程全面剖析會考歷屆考題，手把手培養全題型答題實戰力。除複習國中課綱內容外，亦會提供學生精選試題與詳解。可助學生強化個人弱點與提升複習效率。', 'sample1.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `username` varchar(20) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(16) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `birth` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`username`, `name`, `email`, `password`, `phone`, `gender`, `birth`, `address`, `level`) VALUES
('admin', '謝宥宣', 'jeremy.life0107@gmail.com', 'admin123456', '0987301813', 1, '2002-01-07', '臺北市中正區重慶南路1段122號', 4),
('admin1', '戴育琪', 'kirklan0423@gmail.com', 'admin123456', '0987654321', 0, '2002-04-23', '新北市金山區中正路21號', 4),
('member', '傑克', 'jack123@gmail.com', 'member123456', '0912365479', 1, '2012-10-16', '彰化市師大路二號', 3),
('member2', '阿呆', 'S0954010@gm.ncue.edu.tw', 'member123456', '0987654321', 0, '2000-06-06', '高雄市前鎮區南五路34號', 2);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `email`, `message`) VALUES
(1, '阿呆1', 'jeremy.life0107@gmail.com', 'This is a test.'),
(2, '阿呆2', 'jeremy.life0107@gmail.com', 'This is another test.'),
(3, 'member', 'S0954010@gm.ncue.edu.tw', '教得真的很讚!');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `payment` varchar(20) NOT NULL,
  `bank` int(16) NOT NULL,
  `price` int(11) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `username`, `name`, `email`, `phone`, `address`, `payment`, `bank`, `price`, `status`) VALUES
(1, 'member', '傑克', 'jack123@gmail.com', 987654321, '彰化市師大路二號', 'paypal', 2147483647, 123321123, 1),
(2, 'admin', '謝宥宣', 'S0954010@gm.ncue.edu.tw', 987301813, '高雄市前鎮區南五路34號', 'bank', 0, 26000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_subject`
--

CREATE TABLE `order_subject` (
  `ordernum` int(11) NOT NULL,
  `subject` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_subject`
--

INSERT INTO `order_subject` (`ordernum`, `subject`) VALUES
(1, '1'),
(1, '2'),
(1, '5'),
(2, '1'),
(2, '3'),
(2, '5'),
(2, '7'),
(2, '9');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `star` int(11) NOT NULL,
  `comment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `courseid`, `username`, `star`, `comment`) VALUES
(0, 1, 'member', 4, '課程超級棒，老師教得很好！'),
(1, 1, 'member1', 5, '我覺得老師教得非常好，看一次就能理解。且老師口條非常棒，不用加字幕就能聽得懂。超級讚！'),
(3, 28, '訪客', 4, '課程超棒的'),
(4, 28, 'member', 5, '上完課感覺自己都要變愛因斯坦的。');

-- --------------------------------------------------------

--
-- Table structure for table `usercourse`
--

CREATE TABLE `usercourse` (
  `username` varchar(20) NOT NULL,
  `courseid` int(11) NOT NULL,
  `start` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usercourse`
--

INSERT INTO `usercourse` (`username`, `courseid`, `start`) VALUES
('admin', 1, 20220605),
('admin', 3, 20220605),
('admin', 5, 20220605),
('admin', 7, 20220605),
('admin', 9, 20220605),
('member', 1, 20220604),
('member', 2, 20220506),
('member', 3, 20220604),
('member', 5, 20220604),
('member', 15, 20220125),
('member', 19, 20220604),
('member', 28, 20220604),
('member', 35, 20220604),
('member', 42, 20210723);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`userid`,`courseid`);

--
-- Indexes for table `coupon`
--
ALTER TABLE `coupon`
  ADD PRIMARY KEY (`userid`,`couponid`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_subject`
--
ALTER TABLE `order_subject`
  ADD PRIMARY KEY (`ordernum`,`subject`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usercourse`
--
ALTER TABLE `usercourse`
  ADD PRIMARY KEY (`username`,`courseid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
